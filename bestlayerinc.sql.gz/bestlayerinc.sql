-- Adminer 4.2.2 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

CREATE DATABASE `bestlayerinc` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `bestlayerinc`;

DROP TABLE IF EXISTS `logs`;
CREATE TABLE `logs` (
  `LogID` int(12) NOT NULL AUTO_INCREMENT,
  `CID` int(12) NOT NULL,
  `Date_Log` date NOT NULL,
  `OrderID` int(12) NOT NULL,
  PRIMARY KEY (`LogID`),
  KEY `CID` (`CID`),
  KEY `OrderID` (`OrderID`),
  CONSTRAINT `logs_ibfk_1` FOREIGN KEY (`CID`) REFERENCES `tbl_customer` (`CID`) ON UPDATE CASCADE,
  CONSTRAINT `logs_ibfk_2` FOREIGN KEY (`OrderID`) REFERENCES `tbl_sales_order` (`OrderID`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `tbl_address`;
CREATE TABLE `tbl_address` (
  `AddressID` int(12) NOT NULL AUTO_INCREMENT,
  `CID` int(12) NOT NULL,
  `BuildingNumber` varchar(16) NOT NULL,
  `Street` varchar(30) NOT NULL,
  `City` varchar(20) NOT NULL,
  `Region` varchar(20) NOT NULL,
  `ZipCode` int(10) NOT NULL,
  `Country` varchar(30) NOT NULL,
  `ContactInfo` varchar(30) NOT NULL,
  PRIMARY KEY (`AddressID`),
  KEY `CID` (`CID`),
  KEY `CID_2` (`CID`),
  CONSTRAINT `tbl_address_ibfk_1` FOREIGN KEY (`CID`) REFERENCES `tbl_customer` (`CID`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `tbl_admin`;
CREATE TABLE `tbl_admin` (
  `UserID` int(12) NOT NULL AUTO_INCREMENT,
  `Uname` varchar(16) NOT NULL,
  `PWord` char(32) NOT NULL,
  PRIMARY KEY (`UserID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `tbl_admin` (`UserID`, `Uname`, `PWord`) VALUES
(1,	'loreto',	'5f4dcc3b5aa765d61d8327deb882cf99');

DROP TABLE IF EXISTS `tbl_category`;
CREATE TABLE `tbl_category` (
  `CategoryID` int(12) NOT NULL AUTO_INCREMENT,
  `ProductCategory` varchar(40) NOT NULL,
  `Description` varchar(200) NOT NULL,
  PRIMARY KEY (`CategoryID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `tbl_category` (`CategoryID`, `ProductCategory`, `Description`) VALUES
(2,	'sadasd',	'what the fuck?'),
(4,	'asdasd',	'asdasdasd'),
(6,	'xxx',	'xxx');

DROP TABLE IF EXISTS `tbl_customer`;
CREATE TABLE `tbl_customer` (
  `CID` int(12) NOT NULL AUTO_INCREMENT,
  `Fname` varchar(16) NOT NULL,
  `Lname` varchar(16) NOT NULL,
  `CompName` varchar(45) NOT NULL,
  `Uname` varchar(16) NOT NULL,
  `Pword` char(32) NOT NULL,
  `Email` varchar(30) NOT NULL,
  PRIMARY KEY (`CID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `tbl_items_ordered`;
CREATE TABLE `tbl_items_ordered` (
  `ItemID` int(12) NOT NULL AUTO_INCREMENT,
  `OrderID` int(12) NOT NULL,
  `SKU` varchar(12) NOT NULL,
  `Quantity` int(12) NOT NULL,
  PRIMARY KEY (`ItemID`),
  KEY `OrderID` (`OrderID`),
  KEY `SKU` (`SKU`),
  KEY `SKU_2` (`SKU`),
  CONSTRAINT `tbl_items_ordered_ibfk_1` FOREIGN KEY (`SKU`) REFERENCES `tbl_products` (`SKU`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `tbl_products`;
CREATE TABLE `tbl_products` (
  `SKU` varchar(12) NOT NULL,
  `CategoryID` int(12) NOT NULL,
  `ProductName` varchar(41) NOT NULL,
  `Price` decimal(16,0) NOT NULL,
  `Cost` decimal(16,0) NOT NULL,
  `Color` varchar(15) NOT NULL,
  `Height` decimal(10,0) NOT NULL,
  `Width` decimal(10,0) NOT NULL,
  PRIMARY KEY (`SKU`),
  KEY `CategoryID` (`CategoryID`),
  CONSTRAINT `tbl_products_ibfk_1` FOREIGN KEY (`CategoryID`) REFERENCES `tbl_category` (`CategoryID`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `tbl_products` (`SKU`, `CategoryID`, `ProductName`, `Price`, `Cost`, `Color`, `Height`, `Width`) VALUES
('111111111111',	4,	'Floural Base',	5000,	5000,	'1',	1,	1),
('123123',	4,	'Dildo',	100,	100,	'red',	1,	1),
('as12asda',	2,	'asda sda sdas dasd asdas',	1,	1,	'1',	1,	1),
('SKU',	6,	'sdfs',	1,	1,	'1',	1,	1);

DROP TABLE IF EXISTS `tbl_sales_order`;
CREATE TABLE `tbl_sales_order` (
  `OrderID` int(12) NOT NULL AUTO_INCREMENT,
  `CID` int(12) NOT NULL,
  `OrderDate` date NOT NULL,
  `OrderStatus` varchar(30) NOT NULL,
  `ShippedDate` date NOT NULL,
  `DeliveryDate` date NOT NULL,
  `PromisedDate` date NOT NULL,
  `ShipID` int(12) NOT NULL,
  `DeliveryAddress` varchar(190) NOT NULL,
  PRIMARY KEY (`OrderID`),
  KEY `CID` (`CID`),
  KEY `ShipID` (`ShipID`),
  CONSTRAINT `tbl_sales_order_ibfk_1` FOREIGN KEY (`OrderID`) REFERENCES `tbl_items_ordered` (`OrderID`) ON UPDATE CASCADE,
  CONSTRAINT `tbl_sales_order_ibfk_2` FOREIGN KEY (`ShipID`) REFERENCES `tbl_shippingmethod` (`ShipID`),
  CONSTRAINT `tbl_sales_order_ibfk_3` FOREIGN KEY (`CID`) REFERENCES `tbl_customer` (`CID`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `tbl_shippingmethod`;
CREATE TABLE `tbl_shippingmethod` (
  `ShipID` int(12) NOT NULL AUTO_INCREMENT,
  `ShipName` varchar(30) NOT NULL,
  `ShipDesc` varchar(40) NOT NULL,
  `ShipRate` decimal(12,0) NOT NULL,
  PRIMARY KEY (`ShipID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


-- 2015-11-25 06:43:16
